import os
import re
import json
from setuptools import setup

kwargs = {
        'name': 'jessica',
        'version': '0',
        'description': '',
        'url': '',
        'author': '',
        'author_email': '',
        'license': 'MIT',
        'packages': ['jessica'],
        'zip_safe': False,
        }

setup(**kwargs)



